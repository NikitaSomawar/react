
import { fromJS } from 'immutable';
import { ADD_BANK_TYPE } from './constants';


const initialState = fromJS({
});

function addBankReducer(state = initialState, action) {
    switch (action.type) {
      case ADD_BANK_TYPE:
         return state;
      default:
        return state;
    }
  }
  
  export default addBankReducer;