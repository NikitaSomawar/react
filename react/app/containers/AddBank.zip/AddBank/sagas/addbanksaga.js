import axios from 'axios';
import { put, call, takeLatest ,takeEvery , take } from 'redux-saga/effects';
import { ADD_BANK_API,ADD_BANK_TYPE } from '../constants';

function* submitAddBank(action){
    console.log('in submit add bank');
 
  /*var token = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjVkYmYwMTIyOTgwMDdiYjJkMzAzYzBjOTliMmY3MjUwODRiZmY3MTAifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vYnV5bnN0YS1hZTg2OSIsIm5hbWUiOiJOaWtpdGEgU29tYXdhciIsInBpY3R1cmUiOiJodHRwczovL3Njb250ZW50Lnh4LmZiY2RuLm5ldC92L3QxLjAtMS9jMC4zOS4xMDAuMTAwL3AxMDB4MTAwLzE4ODEzMzU4XzIwOTMzNDEwNTc1NTk0NDBfNDAyMTM5NDUyMzk1MjIzNjMwOF9uLmpwZz9vaD1iMDU2MTExOTc5YjczOGNlMDgwZTQxY2VmNzZlNmFkZCZvZT01QjQ5NTZFOSIsImF1ZCI6ImJ1eW5zdGEtYWU4NjkiLCJhdXRoX3RpbWUiOjE1MTkyOTM5MDAsInVzZXJfaWQiOiJFSnNtZGljV3RoY3BZek9BeVllUFhja1Z3YXQxIiwic3ViIjoiRUpzbWRpY1d0aGNwWXpPQXlZZVBYY2tWd2F0MSIsImlhdCI6MTUxOTI5MzkwMCwiZXhwIjoxNTE5Mjk3NTAwLCJmaXJlYmFzZSI6eyJpZGVudGl0aWVzIjp7ImZhY2Vib29rLmNvbSI6WyIyMjM4MTY2MzUzMDc2OTA5Il19LCJzaWduX2luX3Byb3ZpZGVyIjoiZmFjZWJvb2suY29tIn19.plGuJL1DlBSIy8XZV6tjNfKKCBpTy3K6k_qZIPBADrCL094rR4sTgX9eb_VFAcIokfZJ9uftJ-dN_XgeeOmdBdojMXaB3JZzv-v2QmwFRfFkXN-lvDRfSfaoNqMzkNcFvUZf7qsteVmz_gPqAu_6mV1GobOrEwbfG287kbdejehTaSp5kAEdFDB9lbA0Y_WjG5wyUrcNBoDzUdRc4wFRZ68LwAZmAYIO_QyzQ-gAUy77YYA2me8RxTtoLBl7Mg7QL_k7aUu7CZuUqH4HzX9WoZkrGQu6Cqb6JS4GSOO8Nh2xFlbrRrGNByxMAdD6M3fQqbXSDCCPiKtMhWLsi-3K9A";
  try {
        console.log('abc');
        const commonPostHeader = {
            headers: {
                'Accept':'application/json',
                'Authorization':'Bearer ' + token,
            }
        }
        const httpArgs = [ADD_BANK_API, {"bankName":"Yes","accNo":"017084600000613","ifsc":"YESB0000918‎"}  ,commonPostHeader];

        const { data: {code, model} } = yield call(axios.post, ...httpArgs);
        //console.log(code);
       
    } catch(e) {
      //console.log(e);
    }*/
}


export default function* submitAddBankWatcher(action){
    console.log('in watcher');
    yield takeLatest(ADD_BANK_TYPE,submitAddBank)
}
