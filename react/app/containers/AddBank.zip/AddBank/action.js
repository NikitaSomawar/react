
import { ADD_BANK_TYPE } from './constants';
export function addbank_Action(datapack) {
    const { mobile, token } = datapack;
     console.log(datapack, 'in actions');
    return {
      type:ADD_BANK_TYPE,
      mobile,
      token
    };
  }