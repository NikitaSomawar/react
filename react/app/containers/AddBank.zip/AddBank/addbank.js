import React from 'react';
import { connect } from "react-redux";
import { withRouter } from 'react-router';
import { createStore } from "redux";
import  bhiveReducer  from '../Bhive/reducer';
import makeSelectBhive, { makeSelectCustomer } from '../Bhive/selectors';
import { createStructuredSelector } from 'reselect';
import saga from './saga';
import injectSaga from 'utils/injectSaga';
import { compose } from 'redux';
//import reducer from './reducer';
//import injectReducer from 'utils/injectReducer';
import { addbank_Action } from './action';

export class AddBank extends React.PureComponent {
    constructor(props){
        super(props);

    //console.log(this.props);
      // console.log('state here')
    }
    handelsubmit = (e) =>{
        e.preventDefault();
        var acountNumber = this.refs.acountNumber.value;
        var ifscCode = this.refs.ifscCode.value;
        var bankName = this.refs.bankName.value;
        console.log(acountNumber);
        console.log(ifscCode);
        console.log(bankName);
    }

    getapi = () =>{
        
        var authToken = this.props.Customer.authToken;
        addbank_Action({mobile: 'nikita', token: authToken});




        /*
        alert('hi');
        console.log(this.props);
        console.log(this.props.Customer.authToken);
        fetch(`https://us-central1-buynsta-ae869.cloudfunctions.net/onAddBankRequest`,{
            method: 'POST',
            body:{"bankName":"Yes","accNo":"017084600000613","ifsc":"YESB0000918‎"},
          /*  body: JSON.stringify({
                bankName: "Yes",
                accNo:"017084600000613",
                ifsc:"YESB0000918‎"
            }),*/
            //headers: {"Content-Type": "application/json","Authorization":this.props.Customer.authToken,"Access-Control-Allow-Headers":"Origin","Access-Control-Allow-Origin":"*","Access-Control-Allow-Method":"POST"}
         /*   headers: {'Accept':'application/json',"Authorization":"Bearer " + this.props.Customer.authToken}
          })
          .then(result=> { 
            return  result.json();
          })
          .then((parsedData)=> {
            console.log(parsedData);
          })
        */
    }
    call_test = () =>{
         
        alert('hi');
        console.log(this.props);
        console.log(this.props.Customer.authToken);
        fetch(`https://us-central1-buynsta-ae869.cloudfunctions.net/onAddBankRequest`,{
            method: 'POST',
            body:{"bankName":"Yes","accNo":"017084600000613","ifsc":"YESB0000918‎"},
          /*  body: JSON.stringify({
                bankName: "Yes",
                accNo:"017084600000613",
                ifsc:"YESB0000918‎"
            }),*/
            //headers: {"Content-Type": "application/json","Authorization":this.props.Customer.authToken,"Access-Control-Allow-Headers":"Origin","Access-Control-Allow-Origin":"*","Access-Control-Allow-Method":"POST"}
           headers: {'Accept':'application/json',"Authorization":"Bearer " + this.props.Customer.authToken}
          })
          .then(result=> { 
            return  result.json();
          })
          .then((parsedData)=> {
            console.log(parsedData);
          })
        
    }
    render(){
       // console.log('second one');
       // console.log(this.props);
        return (
        <div>
            <button onClick={this.getapi}>click me</button>
            <button onClick={this.call_test}>TEST</button>
            <h1>coming</h1>
            <div>
				<form method='POST'>
					<div>
                        
						<input type="text" name="bankName" ref='bankName' placeholder="Bank Name"/>
						
					</div>

					<div>
						<input type="text" name="acountNumber" ref='acountNumber' placeholder="Acount Number"/>
						
					</div>
                    <div>
						<input type="text" name="ifscCode" ref='ifscCode'  placeholder="IFSC Code"/>
						
					</div>

					<div>
						<button onClick={this.handelsubmit}>
							Add Bank
						</button>
                    </div>
				</form>
			</div>
            </div>
        )

    }
}

const mapStateToProps = createStructuredSelector({
    bhive: makeSelectBhive(),
    Customer: makeSelectCustomer(),
  });

  function mapDispatchToProps(dispatch) {
    return {
   
        addbank_Action: datapack => {
          dispatch(addbank_Action(datapack))
      },
    };
  }


  const withConnect = connect(mapStateToProps,mapDispatchToProps);
  const withSaga = injectSaga({ key: 'addbank', saga });
  //const withReducer = injectReducer({ key: 'addbank', reducer });

  export default compose(
    withSaga,
    withConnect
   // withReducer
  )(AddBank);
  