import { take, call, put, select, fork } from 'redux-saga/effects';
import submitAddBankWatcher from './sagas/addbanksaga.js';

export default function* rootAddBankSaga() {
    yield [
      fork(submitAddBankWatcher)
    ]
    console.log('in saga.js');
  }