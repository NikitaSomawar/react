export const ADD_BANK_TYPE = 'app/AddBank/ADD_BANK_TYPE';
export const ADD_BANK_TYPE_TEST = 'app/AddBank/ADD_BANK_TYPE_TEST';
export const ADD_BANK_API = 'https://us-central1-buynsta-ae869.cloudfunctions.net/onAddBankRequest';